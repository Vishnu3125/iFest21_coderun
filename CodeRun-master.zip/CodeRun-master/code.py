#Write your code here
fruits = ["apple", "banana", "cherry"]
for x in fruits:
  print(x)
